export const fetchSatellites = async () => {
  try {
    const response = await fetch(
      "https://isro.vercel.app/api/customer_satellites"
    );
    const data = await response.json();
    return data;
  } catch (error) {
    console.error("Error fetching data:", error);
    return { customer_satellites: [] };
  }
};

import React, { useState } from "react";

const SearchBar = ({ onSearch }) => {
  // State variable for user input
  const [searchTerm, setSearchTerm] = useState("");

  // Event handler for input change
  const handleChange = (e) => {
    setSearchTerm(e.target.value);
  };

  // Event handler for search button click
  const handleSearch = () => {
    onSearch(searchTerm);
  };

  // JSX rendering of the component
  return (
    <div className="search-bar">
      <small className="hint">
        Try searching for Germany, France, Korea, Japan, Canada , Indonesia
      </small>
      <div className="input-container">
        <input
          type="text"
          placeholder="Search for a customer satellite by country"
          value={searchTerm}
          onChange={handleChange}
        />
        <button onClick={handleSearch}>Search</button>
      </div>
    </div>
  );
};

export default SearchBar;

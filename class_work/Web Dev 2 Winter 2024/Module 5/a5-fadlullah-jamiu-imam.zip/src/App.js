import React, { useState, useEffect } from "react";
import "./styles.css";
import "mvp.css";
import { fetchSatellites } from "./api";
import SatelliteList from "./SatelliteList";
import SearchBar from "./SearchBar";

function App() {
  // State variables using the useState hook
  const [satellites, setSatellites] = useState([]);
  const [filteredSatellites, setFilteredSatellites] = useState([]);
  const [searchMessage, setSearchMessage] = useState("");

  // useEffect hook to fetch data when the component mounts
  useEffect(() => {
    const fetchData = async () => {
      try {
        const { customer_satellites } = await fetchSatellites();
        console.log("Fetched data:", customer_satellites);

        if (Array.isArray(customer_satellites)) {
          setSatellites(customer_satellites);
        } else {
          console.error("Fetched data is not an array:", customer_satellites);
        }
      } catch (error) {
        console.error("Error fetching data:", error);
      }
    };

    fetchData();
  }, []);

  // Function to handle search based on user input
  const handleSearch = (searchTerm) => {
    if (!searchTerm.trim()) {
      setSearchMessage("Please enter a country name.");
      setFilteredSatellites([]);
    } else {
      const filteredData = satellites.filter((satellite) =>
        satellite.country.toLowerCase().includes(searchTerm.toLowerCase())
      );

      if (filteredData.length === 0) {
        setSearchMessage(`No satellites found for ${searchTerm}.`);
      } else {
        setSearchMessage("");
      }

      setFilteredSatellites(filteredData);
    }
  };

  // JSX to render the component
  return (
    <div className="App">
      <h1>
        Launched Spacecrafts & Rockets data of ISRO🚀 by Customer Satellites
      </h1>
      <SearchBar onSearch={handleSearch} />
      {searchMessage && <p className="message">{searchMessage}</p>}
      {filteredSatellites.length > 0 && (
        <SatelliteList satellites={filteredSatellites} />
      )}
    </div>
  );
}

export default App;

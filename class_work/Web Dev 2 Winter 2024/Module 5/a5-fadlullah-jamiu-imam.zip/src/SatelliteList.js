import React from "react";

const SatelliteList = ({ satellites }) => {
  // JSX rendering of the component
  return (
    <div className="satellite-list">
      {satellites.map((satellite) => (
        <div key={satellite.id} className="satellite-item">
          <h3>{satellite.country}</h3>
          <p>ID: {satellite.id}</p>
          <p>Launch Date: {satellite.launch_date}</p>
          <p>Mass: {satellite.mass}</p>
          <p>Launcher: {satellite.launcher}</p>
        </div>
      ))}
    </div>
  );
};

export default SatelliteList;

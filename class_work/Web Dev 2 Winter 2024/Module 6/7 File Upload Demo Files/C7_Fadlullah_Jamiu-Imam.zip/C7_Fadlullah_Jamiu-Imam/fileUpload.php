<?php

/*******w******** 
    
    Name: Fadlullah Jamiu-Imam
    Date: March 07th, 2024
    Description: Challenge to explore the processing and persistence of form-based file uploads using PHP

****************/

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My File Upload Challenge</title>
</head>
<body>
    <!-- 
        Create a form capable of uploading a single image
        This form should POST to itself (action="fileUpload.php")
    -->
    
    <form method='post' enctype='multipart/form-data'>
        <label for='image'>Image Filename:</label>
        <input type='file' name='image' id='image'>
        <input type='submit' name='submit' value='Upload Image'>
    </form>
    
</body>
</html>
<?php

/*******w******** 
    
    Name:
    Date:
    Description:

****************/

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My File Upload Challenge</title>
</head>
<body>
    <!-- 
        Create a form capable of uploading a single image
        This form should POST to itself (action="fileUpload.php")
    -->
    
</body>
</html>
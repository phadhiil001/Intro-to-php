<!-- /*******w******** 
    
    Name: Fadlullah Jamiu-Imam
    Date: February 1st, 2024
    Description: Navigation menu for the blog

****************/ -->

<nav>
    <ul>
        <li><a href="index.php">My Amazing Blog Post</a></li>
        <li><a href="new_post.php">New Post</a></li>     
    </ul>
</nav>
